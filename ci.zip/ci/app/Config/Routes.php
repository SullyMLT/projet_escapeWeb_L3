<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
//==================================================================================================
use App\Controllers\Accueil;

$routes->get('/', [Accueil::class, 'afficher']);
$routes->get('accueil/afficher', [Accueil::class, 'afficher']);
//$routes->get('accueil/afficher/(:segment)', [Accueil::class, 'afficher']);
//==================================================================================================
use App\Controllers\Compte;
$routes->get('compte/lister', [Compte::class, 'lister']);
// Inscription
$routes->get('compte/creer', [Compte::class, 'creer']);
$routes->post('compte/creer', [Compte::class, 'creer']);
// Connexion
$routes->get('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/connecter', [Compte::class, 'connecter']);

$routes->get('compte/compte_accueil', [Compte::class, 'accueil']);

$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']);

$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);

$routes->get('compte/modifier_compte', [Compte::class, 'modifier_compte']);
$routes->post('compte/modifier_compte', [Compte::class, 'modifier_compte']);
//==================================================================================================
use App\Controllers\Actualite;
$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficher/(:num)', [Actualite::class, 'afficher']);
//==================================================================================================
use App\Controllers\Scenarii;
$routes->get('scenarii/afficher', [Scenarii::class, 'afficher']);
$routes->get('scenarii/gerer', [Scenarii::class, 'gerer']);
$routes->get('scenarii/gerer/activer_desactiver/(:segment)/(:segment)', [Scenarii::class, 'activer_desactiver']);
$routes->get('scenarii/gerer/visualiser/(:segment)', [Scenarii::class, 'visualiser']);

$routes->get('scenarii/creer', [Scenarii::class, 'creer']);
$routes->post('scenarii/creer', [Scenarii::class, 'creer']);

$routes->get('scenarii/gerer/supprimer_confirmer/(:segment)/(:segment)', [Scenarii::class, 'confirmer_supprimer']);
$routes->get('scenarii/gerer/supprimer/(:segment)/(:segment)', [Scenarii::class, 'supprimer']);

//==================================================================================================
use App\Controllers\Etape;
$routes->get('etape/afficher', [Etape::class, 'afficher']);

$routes->get('etape/afficher/(:segment)', [Etape::class, 'afficher']);

$routes->get('etape/afficher/(:segment)/(:num)', [Etape::class, 'afficher']);

$routes->post('etape/valider_premiere_etape', [Etape::class, 'valider_premiere_etape']);

$routes->get('etape/franchir_etape/(:segment)/(:num)', [Etape::class, 'franchir_etape']);
$routes->post('etape/franchir_etape/(:segment)/(:num)', [Etape::class, 'franchir_etape']);

$routes->get('etape/erreur', [Etape::class, 'modification_url']);

$routes->get('etape/afficher/suivante/(:segment)', [Etape::class, 'afficher']);

$routes->get('etape/finaliser_jeu/(:segment)/(:num)', [Etape::class, 'finaliser_jeu']);
$routes->post('etape/finaliser_jeu/(:segment)/(:num)', [Etape::class, 'finaliser_jeu']);

//==================================================================================================