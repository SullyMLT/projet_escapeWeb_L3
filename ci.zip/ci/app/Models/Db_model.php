<?php
namespace App\Models;
use CodeIgniter\Model;
class Db_model extends Model
{
	protected $db;
	protected $encryption;

	public function __construct()
	{
		//$this->db = db_connect(); //charger la base de données
		// ou
		$this->db = \Config\Database::connect();

		helper('text');
	}

/*================================================================================================================
// 										Comptes
================================================================================================================*/

	// fonction qui récupère les comptes dans la base de donnée
	public function get_all_comptes()
	{

		// Utilisation de la VIEW compte_profil
		$requete = "SELECT * FROM compte_profil
					ORDER BY (pfl_validite);";
		
		$resultat = $this->db->query($requete);

		return $resultat->getResultArray();
	}

	/* Fonction qui compte le nombre de compte dans la base de donnée */
	public function get_nb_comptes()
	{
		// FONCTION phpMyAdmin utilisé ici
		$requete = "SELECT nb_compte() as nb_compte;";

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	public function get_validite_all($cpt_login)
	{

		// Utilisation de la VIEW compte_profil
		$requete = 'SELECT * FROM compte_profil
					WHERE pfl_validite = "A"
					EXCEPT
					SELECT * FROM compte_profil
					WHERE cpt_login ="'.$cpt_login.'";';
		
		$resultat = $this->db->query($requete);

		return $resultat->getNumRows();
	}
	// Fonction Récupérant les saisies fait dans compte_creer.php et l'insert dans la table t_compte_cpt dans la base de donnée 
	public function set_compte($saisie)
	{
		//Récuparation (+ traitement si nécessaire) des données du formulaire
		$login=$saisie['pseudo'];
		$sel="MonSel2023uBo!!";
		$mot_de_passe=$saisie['mdp1'];
			
		$sql='INSERT INTO t_compte_cpt VALUES(NULL,'.'"'.htmlspecialchars(addslashes($login)).'"'.',SHA2("'.htmlspecialchars(addslashes($mot_de_passe)).$sel.'", 256));';

		return $this->db->query($sql);
	}

	// Récupère l'id d'un compte en utilisant son login
	public function takeIdFromLogin($pseudo){
		$requete = 'SELECT cpt_id FROM t_compte_cpt WHERE cpt_login ='.'"'.$pseudo.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}
	// Fait l'insertion d'un profil avec l'id du compte (cpt_id) et le rôle associé lors de l'inscription, le compte est désactivé lors de la création de celui-ci
	public function setProfilToAccountAtSignIn($id, $saisie){
		$nom = $saisie['nom'];
		$prenom = $saisie['prenom'];
		$role = $saisie['role'];
		$validite = $saisie['validite'];


		$requete = "INSERT INTO t_profil_pfl (`pfl_role`, `pfl_nom`, `pfl_prenom`, `cpt_id`, `pfl_validite`, `pfl_creation`) VALUES ('".$role."', '".$nom."', '".$prenom."',".$id.", '".$validite."', CURDATE());";

		return $this->db->query($requete);
	}
	// Retourne vrai lorsque le login et le mot de passe son correct et connecte l'utilisateur
	public function connect_compte($u,$p)
	{
		$sel="MonSel2023uBo!!";
		$sql='SELECT cpt_login,cpt_mdp
				FROM t_compte_cpt
				WHERE cpt_login="'.htmlspecialchars(addslashes($u)).'"
				AND cpt_mdp=SHA2("'.htmlspecialchars(addslashes($p)).$sel.'", 256);';
		
		$resultat=$this->db->query($sql);
		if($resultat->getNumRows() > 0){
			return true;
		}else{
			return false;
		}
	}

	// Montre les données liées au compte de la personne connecté
	public function show_profil($user){

		$requete = 'SELECT * FROM compte_profil
		WHERE cpt_login ="'.htmlspecialchars(addslashes($user)).'";';
		
		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// Fonction modifiant le mot de passe lors de la modification de celui-ci
	public function change_password($saisie){

		$sel="MonSel2023uBo!!";
		$pseudo = $saisie['pseudo'];
		$password = $saisie['mdp1'];
		$requete = 'UPDATE t_compte_cpt
					SET cpt_mdp=SHA2("'.htmlspecialchars(addslashes($password)).$sel.'", 256)
					WHERE cpt_login ="'.$pseudo.'";';

		return $this->db->query($requete);
	}

	public function add_news_create_account($cpt_login, $cpt_id){
		$requete = 'CALL ajoute_actualite_creation_compte("'.$cpt_login.'", '.$cpt_id.');';

		return $this->db->query($requete);
	}
/*================================================================================================================
// 												Actualité
================================================================================================================*/

/* Fonction membre à ajouter sous le constructeur et get_all_compte() : */
	public function get_actualite($numero)
	{
		$requete = "SELECT * FROM t_actualite_act WHERE act_id=".$numero.";";

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// affiche les actualitées
	public function show_actualite(){
		$requete = "SELECT act_intitule, act_description, act_creation, cpt_login FROM t_actualite_act
        			JOIN t_compte_cpt USING (cpt_id)
					WHERE act_validite = 'A'
					ORDER BY (act_creation) DESC
					LIMIT 5;";

		$resultat = $this->db->query($requete);

		return $resultat->getResultArray();
	}

	

/*================================================================================================================
// 												Scénarii
================================================================================================================*/
	// Affiche les scénarii
	public function show_scenarii(){

		$requete = "SELECT sce_intitule, sce_image, sce_code, cpt_login FROM t_compte_cpt
						LEFT JOIN t_scenario_sce USING (cpt_id)
						WHERE sce_active = 'A';";

		$resultat = $this->db->query($requete);

		return $resultat->getResultArray();
	}

	// Récupère les informations d'un scénario et de son auteur
	public function is_scenario($scenario_code){

		$requete = 'SELECT * FROM t_scenario_sce
					JOIN t_compte_cpt USING (cpt_id)
					WHERE sce_code = "'.$scenario_code.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// récupère les informations d'un scénario ainsi que son nombre d'étape
	public function show_scenarii_gerer(){

		$requete = "SELECT sce_id, sce_code, sce_intitule, sce_description, sce_active, sce_image, cpt_login, COUNT(etp_id) as nb_etape FROM t_compte_cpt
					JOIN t_scenario_sce USING (cpt_id)
					LEFT JOIN t_etape_etp USING (sce_id)
					GROUP BY (sce_id);";

		$resultat = $this->db->query($requete);

		return $resultat->getResultArray();
	}

	// Change l'état d'un scénario de désactiver à activer
	public function change_scenario_state_to_activate($sce_code){

		$requete = "UPDATE t_scenario_sce
					SET sce_active = 'A'
					WHERE sce_code ='".$sce_code."';";

		return $this->db->query($requete);
	}

	// Change l'état d'un scénario de activer à désactiver
	public function change_scenario_state_to_desactivate($sce_code){

		$requete = "UPDATE t_scenario_sce
					SET sce_active = 'D'
					WHERE sce_code ='".$sce_code."';";

		return $this->db->query($requete);
	}

	// Créer un scénario avec sa description, son intitule, son état et son image
	public function create_scenario($saisie, $cpt_id, $fichier){
		$intitule = $saisie['intitule'];
		$description = $saisie['description'];
		$validite = $saisie['validite'];
		$code = random_string('alnum', 15);

		$requete = "INSERT INTO t_scenario_sce (`sce_code`, `sce_intitule`, `sce_description`, `sce_image`, `sce_active`, `cpt_id`)
					VALUES ('".$code."', '".htmlspecialchars(addslashes($intitule))."', '".htmlspecialchars(addslashes($description))."','".$fichier."', '".$validite."', '".$cpt_id."');";

		return $this->db->query($requete);
	}
	// Vérifie si un scénario à des indices
	public function has_clue($sce_code){

		$requete = 'SELECT ind_id FROM t_scenario_sce
					JOIN t_etape_etp USING (sce_id)
					JOIN t_indice_ind USING (etp_id)
					WHERE sce_code= "'.$sce_code.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getNumRows();
	}

	// supprime un scénario et active 2 trigger qui font les différentes suppression
	public function delete_scenario($sce_code){
		$requete = 'DELETE FROM t_scenario_sce
					WHERE sce_code = "'.$sce_code.'";';

		return $this->db->query($requete);
	}
	// permet de supprimé les indices liées à un scénario
	public function delete_clue($sce_code){
		$requete = 'DELETE FROM t_indice_ind
					WHERE etp_id IN (SELECT etp_id FROM t_etape_etp 
									WHERE sce_id = (SELECT sce_id FROM t_scenario_sce 
													WHERE sce_code = "'.$sce_code.'"));';

		return $this->db->query($requete);
	}

/*================================================================================================================
// 												Etape
================================================================================================================*/

	// affiche l'étape avec son indice associé
	public function show_etape($scenario_code, $difficulte){

		$requete = 'SELECT * FROM t_etape_etp LEFT JOIN t_indice_ind ON t_etape_etp.etp_id=t_indice_ind.etp_id AND ind_difficulte='.$difficulte.' 
					LEFT JOIN t_scenario_sce USING (sce_id)
					LEFT JOIN t_ressource_res USING (res_id) WHERE sce_code = "'.$scenario_code.'" AND etp_ordre = 1 AND etp_etat = "'.'A'.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// Change l'état d'une étape de désactiver à activer
	public function change_etape_state_to_activate($sce_id){

		$requete = "UPDATE t_etape_etp
					SET etp_etat = 'A'
					WHERE sce_id ='".$sce_id."';";

		return $this->db->query($requete);
	}
	// Change l'état d'une étape de activer à désactiver
	public function change_etape_state_to_desactivate($sce_id){

		$requete = "UPDATE t_etape_etp
					SET etp_etat = 'D'
					WHERE sce_id ='".$sce_id."';";

		return $this->db->query($requete);
	}

	// récupère les informations de toutes les étapes d'un scénario
	public function show_etape_scenario($sce_id){

		$requete = 'SELECT * FROM t_etape_etp
					LEFT JOIN t_ressource_res USING (res_id)
					WHERE sce_id ='.$sce_id.';';

		$resultat = $this->db->query($requete);

		return $resultat->getResultArray();
	}

	// Valide la réponse donnée à une étape lors d'un parcours de scénario par un participant
	public function valid_etape($sce_code, $etp_code, $ordre, $etp_reponse, $difficulte){

		if (empty($difficulte)){
			$requete = 'SELECT * FROM t_scenario_sce
					JOIN t_etape_etp USING (sce_id)
					LEFT JOIN t_indice_ind USING (etp_id)
					LEFT JOIN t_ressource_res USING (res_id)
					WHERE sce_code = "'.$sce_code.'" AND etp_code="'.$etp_code.'" AND etp_etat = "'.'A'.'"
						AND etp_reponse="'.htmlspecialchars(addslashes($etp_reponse)).'" AND etp_ordre='.$ordre.';';
		}else{
			$requete = 'SELECT * FROM t_scenario_sce
					JOIN t_etape_etp USING (sce_id)
					LEFT JOIN t_indice_ind USING (etp_id)
					LEFT JOIN t_ressource_res USING (res_id)
					WHERE sce_code = "'.$sce_code.'" AND etp_code="'.$etp_code.'" AND etp_etat = "'.'A'.'"
						AND etp_reponse="'.htmlspecialchars(addslashes($etp_reponse)).'" AND etp_ordre='.$ordre.' AND ind_difficulte='.$difficulte.';';

		}
		$resultat = $this->db->query($requete);

		return $resultat->getNumRows();
	}

	// récupère les informations de l'étape actuel
	public function get_actual_etape($sce_code, $etp_code, $difficulte, $etp_ordre){
		if (empty($difficulte)){
			$ind_difficulte = 0;
		}else{
			$ind_difficulte = $difficulte;
		}

		$requete = 'SELECT * FROM t_etape_etp LEFT JOIN t_indice_ind ON t_etape_etp.etp_id=t_indice_ind.etp_id AND ind_difficulte='.$ind_difficulte.' 
					LEFT JOIN t_scenario_sce USING (sce_id)
					LEFT JOIN t_ressource_res USING (res_id) WHERE sce_code = "'.$sce_code.'" AND etp_code="'.$etp_code.'" AND etp_ordre ='.$etp_ordre.' AND etp_etat = "'.'A'.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}
	// récupère les informations de l'étape suivante 
	public function get_next_etape($sce_code, $etp_ordre, $difficulte){

		if (empty($difficulte)){
			$ind_difficulte = 0;
		}else{
			$ind_difficulte = $difficulte;
		}

		$next_ordre = $etp_ordre + 1;

		$requete = 'SELECT * FROM t_etape_etp LEFT JOIN t_indice_ind ON t_etape_etp.etp_id=t_indice_ind.etp_id AND ind_difficulte='.$ind_difficulte.' 
					LEFT JOIN t_scenario_sce USING (sce_id)
					LEFT JOIN t_ressource_res USING (res_id)
					WHERE sce_code = "'.$sce_code.'" AND etp_ordre ='.$next_ordre.' AND etp_etat = "'.'A'.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// Compte le nombre d'étape liées au scénario
	public function get_nb_etape($sce_code){
		$requete = 'SELECT COUNT(etp_id) as nb_etape FROM t_scenario_sce
					JOIN t_etape_etp USING (sce_id)
					WHERE sce_code = "'.$sce_code.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// insert dans la table des participant l'addresse mail de celui-ci lorsqu'il a fini un scénario
	public function insert_participant($email){
		$requete = 'INSERT INTO t_participant_par (`par_adresse`) VALUES ("'.htmlspecialchars(addslashes($email)).'");';

		return $this->db->query($requete);
	}

	// récupère l'id d'un participant en renseignant son addresse mail
	public function get_id_participant($email){
		$requete = 'SELECT par_id FROM t_participant_par WHERE par_adresse = "'.$email.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// récupère l'id d'un scénario à partir de son code
	public function get_id_scenario($sce_code){
		$requete = 'SELECT sce_id FROM t_scenario_sce WHERE sce_code ="'.$sce_code.'";';

		$resultat = $this->db->query($requete);

		return $resultat->getRow();
	}

	// Insert la participation d'un participant dans le tableau de récapitulation à partir de l'id du scénario, de l'id du participant et de la difficulté
	public function insert_participation($sce_id, $par_id, $difficulte){
		if (empty($difficulte)){
			$requete = 'INSERT INTO t_classement_cla (`sce_id`,`par_id`,`cla_datePremiereReussite`, `cla_difficulteReussite`)
						VALUES ('.$sce_id.', '.$par_id.', NOW(), 0);';
		}else{
			$requete = 'INSERT INTO t_classement_cla (`sce_id`,`par_id`,`cla_datePremiereReussite`, `cla_difficulteReussite`)
						VALUES ('.$sce_id.', '.$par_id.', NOW(), '.$difficulte.');';
		}
		return $this->db->query($requete);
	}


}
