<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Actualite extends BaseController
{
	public function __construct()
	{
		//...
	}
	public function afficher($numero = 0)
	{
		$model = model(Db_model::class);
		if ($numero == 0)
		{
			/* redirection vers la page d'accueil */
			return redirect()->to('/');
		}
		else{
			$data['titre'] = 'Actualité :';
			$data['news'] = $model->get_actualite($numero);
			
			return view('templates/haut', $data)
				. view('templates/menu_visiteur')
				. view('affichage_actualite')
				. view('templates/bas');
		}
	}
}
