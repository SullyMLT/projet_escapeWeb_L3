<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Scenarii extends BaseController
{
	public function __construct()
	{
		helper('form');
 		$this->model = model(Db_model::class);
	}

	// Fonction permettant de récupérer tout les scénarii
	public function afficher()
	{
		$data['all_scenarii'] = $this->model->show_scenarii();

		return view('templates/haut', $data)
		. view('templates/menu_visiteur')
		. view('scenario/affichage_scenario')
		. view('templates/bas');
	}

	// Récupère tout les scénarii pour les affichers sur la page de gestion des scénarii, d'un compte organisateur connecté
	public function gerer(){

		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){
				$data['all_scenarii'] = $this->model->show_scenarii_gerer();

				return view('templates/haut2', $data)
				. view('templates/menu_organisateur')
				. view('scenario/gerer_scenario')
				. view('templates/bas2');
			}else{
				return redirect()->to('compte/deconnecter');
			}
		}else{
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
		
	}
	// Permet de désactiver ou d'activer un scénario
	public function activer_desactiver($sce_code="", $cpt_login=""){

		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){

				if ($sce_code!="" && $cpt_login!=""){
					
					if ($session->get('user') == $cpt_login){
						$sce['scenario'] = $this->model->is_scenario($sce_code);

						if (!empty($sce['scenario'])){
							// Désactive un scénario et ses étapes
							if ($sce['scenario']->sce_active == 'A'){
								$this->model->change_scenario_state_to_desactivate($sce_code);
								$this->model->change_etape_state_to_desactivate($sce['scenario']->sce_id);
							}
							// Active un scénario et ses étapes
							if ($sce['scenario']->sce_active == 'D'){
								$this->model->change_scenario_state_to_activate($sce_code);
								$this->model->change_etape_state_to_activate($sce['scenario']->sce_id);
							}
						}else{
							// Si ce n'est pas un scénario, on est redirigé vers la page d'accueil du compte connecté
							return view('templates/haut2')
								. view('templates/menu_organisateur')
								. view('connexion/compte_accueil')
								. view('templates/bas2');
						}
					}else{
						// Il n'est pas possible de changer l'état d'un scénario dont on est pas l'auteur
						return view('templates/haut2')
							. view('templates/menu_organisateur')
							. view('connexion/compte_accueil')
							. view('templates/bas2');
					}
				}
				// Tout c'est bien déroulé on "rafraichie" la page pour actualiser
				return redirect()->to('scenarii/gerer');

			}else{
				// L'utilisateur connecté n'est pas un organisateur, donc il est déconnecté
				return redirect()->to('compte/deconnecter');
			}
		}else{
			// L'utilisateur voulant aller sur la page n'est pas connecté, donc il est redirigé vers la page de connexion
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
	}
	// Fonction permettent de visualisé toutes les données d'un scénario et le redirigant vers une page de visualisation
	public function visualiser($sce_code=""){

		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){
			
				$data['scenario'] = $this->model->is_scenario($sce_code);

				if ($data['scenario']!= NULL){
					$data['all_etape'] = $this->model->show_etape_scenario($data['scenario']->sce_id);

					return view('templates/haut2', $data)
					. view('templates/menu_organisateur')
					. view('scenario/visualiser_scenario')
					. view('templates/bas2');
				}else{
					return view('templates/haut2', $data)
					. view('templates/menu_organisateur')
					. view('scenario/visualiser_scenario')
					. view('templates/bas2');
				}
			}else{
				return redirect()->to('compte/deconnecter');
			}
		}else{
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
	}
	// Fonction permettant de créer un scénario
	public function creer()
	{
		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){
				// L’utilisateur a validé le formulaire en cliquant sur le bouton
				if ($this->request->getMethod()=="post")
				{
					if (! $this->validate([
					'auteur' => 'required',
					'intitule' => 'required|max_length[128]|min_length[8]',
					'description' => 'required|max_length[1024]',
					'validite' => 'required|in_list[A,D]',
					'fichier' => [
						'label' => 'Fichier image',
						'rules' => [
						'uploaded[fichier]',
						'is_image[fichier]',
						'mime_in[fichier,image/jpg,image/jpeg,image/gif,image/png,image/webp]',
						'max_size[fichier,100]',
						'max_dims[fichier,1024,768]',
						]]
					],
					[ // Configuration des messages d’erreurs
						'auteur' => [
							'required' => ' '
						],
						'intitule' => [
							'required' => 'Veuillez entrer un intitule !',
							'min_length' => 'Veuillez entrer un pseudo contenant au moins 8 caractères'
						],
						'description' => [
							'required' => 'Veuillez entrer la description du scenario !',
							'max_length' => 'La description du scénario est trop longue !'
						],
						'validite' => [
							'required' => 'Veuillez sélectionner un état !',
							'in_list' => 'Veuillez choisir un état !'
						]
					]
					))
					{
						// La validation du formulaire a échoué, retour au formulaire !
						return view('templates/haut2', ['titre' => '<h2>Créer un scénario</h2>'])
						. view('templates/menu_organisateur')
						. view('scenario/creer_scenario')
						. view('templates/bas2');
					}
					// La validation du formulaire a réussi, traitement du formulaire
					$recuperation = $this->validator->getValidated();
					$data['id'] = $this->model->takeIdFromLogin($recuperation['auteur']);
					$fichier=$this->request->getFile('fichier');

					if(!empty($fichier)){
						// Récupération du nom du fichier téléversé
						$nom_fichier=$fichier->getName();
						// Dépôt du fichier dans le répertoire ci/public/uploads
						if($fichier->move("uploads",$nom_fichier)){
							$chemin_fichier = "uploads/".$nom_fichier;
							// + Mettre ici l’appel de la fonction membre du Db_model
							$this->model->create_scenario($recuperation, $data['id']->cpt_id, $chemin_fichier);
							// + L’affichage de la page indiquant l’ajout du scénario !
							if ($recuperation['validite']=='A'){
								$data['etatChoisi']="Activé";
							}
							if($recuperation['validite']=='D'){
								$data['etatChoisi']="Désactivé";
							}
							$data['auteur'] = $recuperation['auteur'];
							$data['image'] = $chemin_fichier;
							$data['intitule'] = $recuperation['intitule'];
							$data['description'] = $recuperation['description'];
							//================================================================================
		
							return view('templates/haut2', $data)
							. view('templates/menu_organisateur', ['titre' => '<h2 class="text-success">Scénario créé avec succès</h2>'])
							. view('scenario/succes_scenario')
							. view('templates/bas2');
						}
					}
					//================================================================================
				}
				// affiche le formulaire
				return view('templates/haut2', ['titre' => '<h2>Créer un scenario</h2>'])
				. view('templates/menu_organisateur')
				. view('scenario/creer_scenario')
				. view('templates/bas2');
			}else{
				return redirect()->to('/compte/deconnecter');
			}
		}else{
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
 	}
	// Fonction envoyant l'utilisateur effectuant une suppression d'une scénario sur une autre page demandant la confirmation de cette suppression
	public function confirmer_supprimer($sce_code, $cpt_login){
		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){
				$data['sce_code'] = $sce_code;
				$data['cpt_login'] = $cpt_login;
				
				return view('templates/haut2', $data)
					. view('templates/menu_organisateur')
					. view('scenario/confirmer_supp_scenario')
					. view('templates/bas2');
			}else{
				return redirect()->to('compte/deconnecter');
			}
			return redirect()->to('scenarii/gerer');
		}else{
			// L'utilisateur voulant aller sur la page n'est pas connecté, donc il est redirigé vers la page de connexion
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}

	} 
	// Supprime un scénario en utilisant son code et l'auteur de celui-ci
	public function supprimer($sce_code="", $cpt_login=""){
		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='O'){

				if ($sce_code!="" && $cpt_login!=""){

					if ($session->get('user') == $cpt_login){
						$sce['scenario'] = $this->model->is_scenario($sce_code);

						if (!empty($sce['scenario'])){

							$sce['has_clue'] = $this->model->has_clue($sce['scenario']->sce_code);
							if ($sce['has_clue']>0){
								$this->model->delete_clue($sce['scenario']->sce_code);
							}

							$this->model->delete_scenario($sce['scenario']->sce_code);
						}else{
							// Si ce n'est pas un scénario, on est redirigé vers la page d'accueil du compte connecté
							return view('templates/haut2')
								. view('templates/menu_organisateur')
								. view('connexion/compte_accueil')
								. view('templates/bas2');
						}
					}else{
						// Il n'est pas possible de changer l'état d'un scénario dont on est pas l'auteur
						return view('templates/haut2')
							. view('templates/menu_organisateur')
							. view('connexion/compte_accueil')
							. view('templates/bas2');
					}
				}
				// Tout c'est bien déroulé on "rafraichie" la page pour actualiser
				return redirect()->to('scenarii/gerer');

			}else{
				// L'utilisateur connecté n'est pas un organisateur, donc il est déconnecté
				return redirect()->to('compte/deconnecter');
			}
		}else{
			// L'utilisateur voulant aller sur la page n'est pas connecté, donc il est redirigé vers la page de connexion
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
	}
}

?>