<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Compte extends BaseController
{
	public function __construct()
	{
		helper('form');
 		$this->model = model(Db_model::class);
	}

	// Permet de lister tout les comptes et le nombre de compte
	public function lister()
	{
		$session=session();
		if ($session->has('user')){
			$data['titre'] = "Liste de tous les comptes";

			$data['infoCompte'] = $this->model->get_all_comptes();
			$data['total_compte'] = $this->model->get_nb_comptes();
			$data['adminOnly'] = $this->model->get_validite_all($session->get('user'));

			if($session->get('role')=='A'){
				return view('templates/haut2',$data)
				. view('templates/menu_administrateur')
				. view('compte/affichage_comptes')
				. view('templates/bas2');
			}else if ($session->get('role')=='O'){
				return view('templates/haut2',$data)
				. view('templates/menu_organisateur')
				. view('connexion/compte_accueil')
				. view('templates/bas2');
			}else{
				return redirect()->to('/');
			}
		}else{
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
	}

	// Fonction permettant l'insertion des différentes informations récupérées dans les champs remplissable du formulaire et de créer un compte
	public function creer()
	{
		$session=session();
		if ($session->has('user')){
			if($session->get('role')=='A'){
				// L’utilisateur a validé le formulaire en cliquant sur le bouton
				if ($this->request->getMethod()=="post")
				{
					if (! $this->validate([
					'pseudo' => 'required|max_length[45]|min_length[8]|is_unique[t_compte_cpt.cpt_login]',
					'nom' => 'required|max_length[80]',
					'prenom' => 'required|max_length[80]',
					'mdp1' => 'required|max_length[255]|min_length[8]',
					'mdp2' => 'required|max_length[255]|matches[mdp1]',
					'role' => 'required|in_list[A,O]',
					'validite' => 'required|in_list[A,D]'
					],
					[ // Configuration des messages d’erreurs
						'pseudo' => [
						'required' => 'Veuillez entrer un pseudo !',
						'min_length' => 'Veuillez entrer un pseudo contenant au moins 8 caractères',
						'is_unique' => 'Ce pseudo est déjà utilisé !'
						],
						'nom' => [
							'required' => 'Veuillez entrer votre nom !',
							'max_length' => 'Le nom est trop long !'
						],
						'prenom' => [
							'required' => 'Veuillez entrer votre prénom !',
							'max_length' => 'Le nom est trop long !'
						],
						'mdp1' => [
							'required' => 'Veuillez entrer un mot de passe !',
							'min_length' => 'Le mot de passe saisi est trop court !'
						],
						'mdp2' => [
							'required' => 'Veuillez entrer un mot de passe !',
							'matches' => 'Le mot de passe ne correspond pas au champ précédent !'
						],
						'role' => [
							'required' => 'Veuillez sélectionner un rôle !',
							'in_list' => 'Veuillez choisir un rôle !'
						],
						'validite' => [
							'required' => 'Veuillez sélectionner un état !',
							'in_list' => 'Veuillez choisir un état !'
						],
						]
					))
					{
						// La validation du formulaire a échoué, retour au formulaire !
						return view('templates/haut2', ['titre' => 'Créer un compte'])
						. view('templates/menu_administrateur')
						. view('compte/compte_creer')
						. view('templates/bas2');
					}
					// La validation du formulaire a réussi, traitement du formulaire
					$recuperation = $this->validator->getValidated();
					$this->model->set_compte($recuperation);
					$data['le_compte']=$recuperation['pseudo'];
					//================================================================================
					// Récupération de login pour récupérer l'id afin de pouvoir faire l'insertion
					// des données dans la table des profils avec la date de création, le role,
					// l'id du compte, la validité, le nom, le prénom.
					$data['id'] = $this->model->takeIdFromLogin($data['le_compte']);
					$this->model->setProfilToAccountAtSignIn($data['id']->cpt_id, $recuperation);
					//================================================================================
					$data['le_message']="Nouveau nombre de comptes : ";
					//Appel de la fonction créée dans le précédent tutoriel :
					$data['le_total']=$this->model->get_nb_comptes();
					if ($recuperation['role']=='O'){
						$data['roleChoisi']="Organisateur";
						$this->model->add_news_create_account($data['le_compte'], $data['id']->cpt_id);
					}else if($recuperation['role']=='A'){
						$data['roleChoisi']="Administrateur";
					}
					if ($recuperation['validite']=='A'){
						$data['etatChoisi']="Activé";
					}else if($recuperation['validite']=='D'){
						$data['etatChoisi']="Désactivé";
					}
					$data['nom'] = $recuperation['nom'];
					$data['prenom'] = $recuperation['prenom'];
					return view('templates/haut2', $data)
					. view('templates/menu_administrateur')
					. view('compte/compte_succes')
					. view('templates/bas2');
				}
			}else if ($session->get('role')=='O'){
				return view('templates/haut2', $data)
					. view('templates/menu_organisateur')
					. view('compte/compte_accueil')
					. view('templates/bas2');
			}else{
				return redirect()->to('/compte/deconnecter');
			}
			return view('templates/haut2', ['titre' => 'Créer un compte'])
					. view('templates/menu_administrateur')
					. view('compte/compte_creer')
					. view('templates/bas2');
		}else{
			return view('templates/haut', ['titre' => 'Se connecter', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
 	}

	// Fonction autorisant ou non à se connecter au site de l'appli web
	public function connecter()
	{
	 // L’utilisateur a validé le formulaire en cliquant sur le bouton
		if ($this->request->getMethod()=="post"){
			$pseudo = $this->request->getVar('pseudo');
			$mdp = $this->request->getVar('mdp');
			
			if (empty($pseudo) && empty($mdp)) {

				// Réafficher la page de connexion avec le message d'erreur
				return view('templates/haut', ['titre' => '<h2>Se connecter</h2>', 'champsVide' => '<h4 class="text-danger">Veuillez remplir tous les champs.</h4>'])
					. view('templates/menu_visiteur')
					. view('connexion/compte_connecter')
					. view('templates/bas');
			}else{
				if (! $this->validate([
				'pseudo' => 'required',
				'mdp' => 'required'
				],
				[ // Configuration des messages d’erreurs
					'pseudo' => [
					'required' => 'Identifiants erronés ou inexistants !',
					
					],
					'mdp' => [
						'required' => 'Veuillez entrer un mot de passe !',
					],]))
				{ // La validation du formulaire a échoué, retour au formulaire !
					return view('templates/haut', ['titre' => '<h2>Se connecter</h2>', 'champsVide' => ''])
						. view('templates/menu_visiteur')
						. view('connexion/compte_connecter')
						. view('templates/bas');
				}
				// La validation du formulaire a réussi, traitement du formulaire
				$username=$this->request->getVar('pseudo');
				$password=$this->request->getVar('mdp');
				if ($this->model->connect_compte($username,$password)==true)
				{
					$data['profil'] = $this->model->show_profil($username);

					if ($data['profil']->pfl_validite == 'A'){
						$session=session();
						$session->set('user',$username);
						$session->set('role', $data['profil']->pfl_role);
						$session->set('validite', $data['profil']->pfl_validite);

						if ($data['profil']->pfl_role == 'A'){

							return view('templates/haut2')
							. view('templates/menu_administrateur')
							. view('connexion/compte_accueil')
							. view('templates/bas2');

						}else if($data['profil']->pfl_role == 'O'){

							return view('templates/haut2')
							. view('templates/menu_organisateur')
							. view('connexion/compte_accueil')
							. view('templates/bas2');

						}
						
					}else{
						return redirect()->to('/compte/connecter');
					}	
				}else{
					return view('templates/haut', ['titre' => '<h2>Se connecter</h2>', 'champsVide' => '<h4 class="text-danger">Les identifiants sont incorrects</h4>'])
						. view('templates/menu_visiteur')
						. view('connexion/compte_connecter')
						. view('templates/bas');
				}
			}
		}
		// L’utilisateur veut afficher le formulaire pour se conncecter
		return view('templates/haut', ['titre' => '<h2>Se connecter</h2>', 'champsVide' => ''])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
	}

	// Affiche le profil de l'utilisation connecté (organisateur ou administrateur)
	public function afficher_profil()
	{
		$session=session();
		if ($session->has('user')){

			$data['profil'] = $this->model->show_profil($session->get('user'));

			if($session->get('role')=='A'){
				return view('templates/haut2',$data)
				. view('templates/menu_administrateur')
				. view('connexion/compte_profil')
				. view('templates/bas2');
			}else if ($session->get('role')=='O'){
				return view('templates/haut2',$data)
				. view('templates/menu_organisateur')
				. view('connexion/compte_profil')
				. view('templates/bas2');
			}
			
		}else{
			return view('templates/haut', ['titre' => 'Se connecter'])
			. view('templates/menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
		}
	}

	// Page d'accueil des organisateurs ou des administrateurs
	public function accueil(){
		$session=session();
		if ($session->has('user')){

			if($session->get('role')=='A'){
				return view('templates/haut2')
				. view('templates/menu_administrateur')
				. view('connexion/compte_accueil')
				. view('templates/bas2');
			}else if ($session->get('role')=='O'){
				return view('templates/haut2')
				. view('templates/menu_organisateur')
				. view('connexion/compte_accueil')
				. view('templates/bas2');
			}
			return redirect()->to('/compte/deconnecter');
		}else{
			return view('templates/haut')
				. view('templates/menu_visiteur')
				. view('affichage_accueil')
				. view('templates/bas');
		}
	}

	// Déconnecte l'utilisateur connecté cliquant sur déconnexion
	public function deconnecter()
	{
		$session=session();
		$session->destroy();

		return view('templates/haut', ['titre' => '<h2>Se connecter</h2>', 'champsVide' => ''])
		. view('templates/menu_visiteur')
		. view('connexion/compte_connecter')
		. view('templates/bas');
	}

	// Permet de modifier le mot de passe de son profil
	public function modifier_compte(){
		$session=session();
		if ($session->has('user')){
			if($session->get('validite')=='A'){
				$data['profil'] = $this->model->show_profil($session->get('user'));
				if ($this->request->getMethod()=="post"){
					if (! $this->validate([
						'pseudo' => 'required',
						'mdp1' => 'required|max_length[255]|min_length[8]',
						'mdp2' => 'required|max_length[255]|matches[mdp1]'
						],
						[ // Configuration des messages d’erreurs
							'pseudo' => [
								'required' => ''
							],
							'mdp1' => [
								'required' => 'Champ de saisie de mot de passe est vide',
								'min_length' => 'Veuillez rentrer un mot de passe d\'au moins 8 caractères !'
							],
							'mdp2' => [
								'required' => 'Champ de saisie de confirmation mot de passe est vide',
								'matches' => 'Confirmation du mot de passe erronée, veuillez réessayer !'
							],
							]
						))
					{
						if ($session->get('role')=='A'){
							// La validation du formulaire a échoué, retour au formulaire !
							return view('templates/haut2', ['titre' => 'Modifier le mot de passe'])
							. view('templates/menu_administrateur', $data)
							. view('connexion/compte_modifier_compte')
							. view('templates/bas2');

						}else if ($session->get('role')=='O'){
							// La validation du formulaire a échoué, retour au formulaire !
							return view('templates/haut2', ['titre' => 'Modifier le mot de passe'])
							. view('templates/menu_organisateur', $data)
							. view('connexion/compte_modifier_compte')
							. view('templates/bas2');
						}
					}
					// La validation du formulaire a réussi, traitement du formulaire
					$recuperation = $this->validator->getValidated();
					$this->model->change_password($recuperation);

					if ($session->get('role')=='A'){

						return view('templates/haut2', ['titre' => 'Créer un compte'])
						. view('templates/menu_administrateur', $data)
						. view('connexion/compte_profil')
						. view('templates/bas2');

					}else if ($session->get('role')=='O'){

						return view('templates/haut2', ['titre' => 'Créer un compte'])
						. view('templates/menu_organisateur', $data)
						. view('connexion/compte_profil')
						. view('templates/bas2');

					}
				}else{
					
					if ($session->get('role')=='A'){

						return view('templates/haut2', ['titre' => 'Modifier le mot de passe'])
						. view('templates/menu_administrateur', $data)
						. view('connexion/compte_modifier_compte')
						. view('templates/bas2');

					}else if ($session->get('role')=='O'){

						return view('templates/haut2', ['titre' => 'Modifier le mot de passe'])
						. view('templates/menu_organisateur', $data)
						. view('connexion/compte_modifier_compte')
						. view('templates/bas2');

					}
				}
			}else{
				return redirect()->to('/compte/deconnecter');
			}
		}else{
			return view('templates/haut', ['titre' => 'Créer un compte'])
					. view('templates/menu_visiteur')
					. view('connexion/compte_connecter')
					. view('templates/bas');
		}
	}
}