<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Etape extends BaseController
{
	public function __construct()
	{
		helper('form');
		$this->model = model(Db_model::class);
	}

	// affiche la première étape d'un scénario lié à ça difficulté
	public function afficher($scenario_code="", $difficulte=0)
	{
		$model = model(Db_model::class);

		if ($difficulte < 0 || $difficulte > 3){
			return redirect()->to('/');
		}
		if (!empty($scenario_code) && $difficulte!=0){
			$data['etape'] = $this->model->show_etape($scenario_code, $difficulte);
			

			if (empty($data['etape'])){
				return view('templates/haut', $data)
				. view('templates/menu_visiteur', ['titre' => ' '])
				. view('etape/affichage_etape')
				. view('templates/bas');
			}

			$data['next_etape'] = $this->model->get_next_etape($scenario_code, $data['etape']->etp_ordre, $difficulte);

			return view('templates/haut', $data)
			. view('templates/menu_visiteur', ['titre' => ' '])
			. view('etape/affichage_etape')
			. view('templates/bas');
		}else{
			return redirect()->to('/scenarii/afficher');
		}
	}

	// Fonction permettant le franchissement d'une étape en vérifiant la réponse soumise et s'il y a bien une réponse dans le champs réponse
	// si oui alors celle-ci est traitter et si elle est valide et qu'il y a encore d'autre étape ensuite alors on affiche l'étape suivant sinon
	// le formulaire de fin de scénario
	public function franchir_etape($etp_code="", $difficulte=0){
		// Si on valide une réponse on fait les différentes vérification ensuite
		if ($this->request->getMethod()=="post")
		{
			$datavalid['sce_code'] = $this->request->getPost('sce_code');
			$datavalid['etp_code'] = $this->request->getPost('etp_code');
			$datavalid['etp_ordre'] = $this->request->getPost('ordre');
			$datavalid['reponse'] = $this->request->getPost('reponse');
			// Test si le champs remplissable de la réponse est vide ou non
			if (! $this->validate([
				'reponse' => 'required'
			],
			[
				'reponse' => [
					// message d'erreur renvoyer s'il est vide lors de la validation
					'required' => 'Veuillez rentrer une réponse avant de valider'
				]
			]))
			{
				// Réaffiche la page avec le message d'erreur lorsque ce champs est validé en étant vide
				$data['etape'] = $this->model->get_actual_etape($datavalid['sce_code'], $datavalid['etp_code'], $difficulte, $datavalid['etp_ordre']);
				$data['next_etape'] = $this->model->get_next_etape($datavalid['sce_code'], $datavalid['etp_ordre'], $difficulte);
				return view('templates/haut', $data)
				. view('templates/menu_visiteur', ['titre' => ' '])
				. view('etape/etape_suivante')
				. view('templates/bas');

			}else{
				$data['reponse'] = $this->model->valid_etape($datavalid['sce_code'], $datavalid['etp_code'], $datavalid['etp_ordre'], $datavalid['reponse'], $difficulte);
				// Test si la réponse donné par l'utilisateur est valide ou non renvoie 1 si elle est valide
				if ($data['reponse']==1){

					$data['etape'] = $this->model->get_next_etape($datavalid['sce_code'], $datavalid['etp_ordre'], $difficulte);
					// Test si il y a une étape ensuite
					if ($data['etape']!=NULL){
						// S'il y a bien une étape ensuite
						$data['next_etape'] = $this->model->get_next_etape($datavalid['sce_code'],$data['etape']->etp_ordre, $difficulte);
						if ($data['next_etape']!=NULL){
							return view('templates/haut', $data)
							. view('templates/menu_visiteur', ['titre' => ' '])
							. view('etape/etape_suivante')
							. view('templates/bas');
						}else{
							$data['next_etape'] = $this->model->get_next_etape($datavalid['sce_code'],$datavalid['etp_ordre'], $difficulte);
							return view('templates/haut', $data)
							. view('templates/menu_visiteur', ['titre' => ' '])
							. view('etape/etape_suivante')
							. view('templates/bas');
						}
						
					}else{
						// S'il n'y a plus d'étape ensuite cela donne le formulaire de participation à remplir
						$data['etape'] = $this->model->get_actual_etape($datavalid['sce_code'], $datavalid['etp_code'], $difficulte, $datavalid['etp_ordre']);
						$data['nb_etape'] = $this->model->get_nb_etape($datavalid['sce_code']);
						if ($data['nb_etape']->nb_etape == $datavalid['etp_ordre']){
							return view('templates/haut', $data)
							. view('templates/menu_visiteur', ['titre' => '<h2 class="text-success">Félicitation vous avez fini le scénario !<h2>'])
							. view('etape/finaliser_jeu')
							. view('templates/bas');
						}
						return redirect()->to('/scenarii/afficher');
					}
				}else{
					// La réponse n'est pas valide et renvoie le message Réponse non valide au dessus du champs de réponse
					$data['etape'] = $this->model->get_actual_etape($datavalid['sce_code'], $datavalid['etp_code'], $difficulte, $datavalid['etp_ordre']);
					$data['next_etape'] = $this->model->get_next_etape($datavalid['sce_code'], $datavalid['etp_ordre'], $difficulte);
					return view('templates/haut', $data)
					. view('templates/menu_visiteur', ['titre' => '<h2 class="text-danger">Réponse non valide<h2>'])
					. view('etape/etape_suivante')
					. view('templates/bas');
				}
			}
		}else{
			if (empty($datavalid)){
				return redirect()->to('etape/erreur');
			}
			// Affiche l'étape actuel lorsque l'on arrive sur la page
			$data['etape'] = $this->model->get_actual_etape($datavalid['sce_code'], $etp_code, $difficulte, $datavalid['etp_ordre']);
			$data['next_etape'] = $this->model->get_next_etape($datavalid['sce_code'], $datavalid['etp_ordre'], $difficulte);
			return view('templates/haut', $data)
			. view('templates/menu_visiteur', ['titre' => ' '])
			. view('etape/etape_suivante')
			. view('templates/bas');
		}
	}


	// Fonction affichant le formulaire lorsqu'un participant à fini le scénario qui l'a fini
	public function finaliser_jeu($etp_code, $difficulte){
		// Si on valide une réponse on fait les différentes vérification
		if ($this->request->getMethod()=="post")
		{
			$datavalid['sce_code'] = $this->request->getPost('sce_code');
			$datavalid['etp_code'] = $this->request->getPost('etp_code');
			$datavalid['etp_ordre'] = $this->request->getPost('ordre');
			$datavalid['difficulte'] = $this->request->getPost('difficulte');
			$datavalid['email'] = $this->request->getPost('email');

			if ($datavalid['etp_code'] != $etp_code){
				return redirect()->to('/scenarii/afficher');
			}
			if ($datavalid['difficulte'] != $difficulte){
				return redirect()->to('/scenarii/afficher');
			}
			// Test si le champs remplissable de la réponse est vide ou non
			if (! $this->validate([
				'email' => 'required|is_unique[t_participant_par.par_adresse]'
			],
			[
				'email' => [
					// message d'erreur renvoyer s'il est vide lors de la validation
					'required' => 'Veuillez rentrer une adresse e-mail !',
					'is_unique' => 'Cette adresse e-mail est déjà utilisé !'
				]
			]))
			{
				// Réaffiche la page avec le message d'erreur lorsque ce champs est validé en étant vide
				$data['etape'] = $this->model->get_actual_etape($datavalid['sce_code'], $etp_code, $difficulte, $datavalid['etp_ordre']);
				return view('templates/haut', $data)
				. view('templates/menu_visiteur', ['titre' => '<h2 class="text-success">Félicitation vous avez fini le scénario !<h2>'])
				. view('etape/finaliser_jeu')
				. view('templates/bas');

			}else{
				$this->model->insert_participant($datavalid['email']);

				$data['par_id'] = $this->model->get_id_participant($datavalid['email']);
				$data['sce_id'] = $this->model->get_id_scenario($datavalid['sce_code']);

				$this->model->insert_participation($data['sce_id']->sce_id, $data['par_id']->par_id, $datavalid['difficulte']);

				return redirect()->to('/scenarii/afficher');
			}
		}else{
			if (empty($datavalid)){
				return redirect()->to('etape/erreur');
			}
			// Réaffiche la page avec le message d'erreur lorsque ce champs est validé en étant vide
			return view('templates/haut')
			. view('templates/menu_visiteur', ['titre' => ' '])
			. view('etape/finaliser_jeu')
			. view('templates/bas');
		}
	}

	public function modification_url(){

		return view('templates/haut')
			. view('templates/menu_visiteur')
			. view('etape/err_etape')
			. view('templates/bas');
	}
}

?>
